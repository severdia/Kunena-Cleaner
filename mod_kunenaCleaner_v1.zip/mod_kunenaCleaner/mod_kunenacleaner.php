<?php
/**
 * Kunena Cleaner Module Entry Point
 *  
 */
// No direct access
defined('_JEXEC') or die;